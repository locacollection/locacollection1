# LOCA COLLECTION — Online Demo

This is a **static online demo package** designed so the LOCA storefront and admin interface can be deployed to a static hosting service and opened from a mobile browser.

## Important

This is NOT the production backend.

- Demo data is stored in the visitor's browser with localStorage.
- No real payment is processed.
- No real customer authentication/database is connected.
- The production Node + SQLite project remains in the separate `loca-pakistan-ecommerce-admin-v1` package.

## Files

- `public/index-demo.html` — demo landing page
- `public/shop.html` — storefront
- `public/admin.html` — admin UI
- `public/demo.js` — browser-only demo data adapter
- `netlify.toml` — Netlify publish configuration
- `vercel.json` — Vercel configuration

## Fastest deployment

### Netlify
Create a new site and upload the `public` folder as the publish directory.

### Vercel
Import this project and deploy. The included `vercel.json` points the deployment at `public`.

After deployment:

- `/index-demo.html` — demo landing page
- `/shop.html` — storefront
- `/admin.html` — admin

## Production next phase

Connect the storefront and admin UI to the Node/Express + SQLite/PostgreSQL backend, then add real login, checkout, order creation, email/WhatsApp notifications, and a supported Pakistani payment gateway.
